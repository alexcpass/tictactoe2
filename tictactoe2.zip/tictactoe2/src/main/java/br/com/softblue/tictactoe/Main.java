package br.com.softblue.tictactoe;

import br.com.softblue.tictactoe.core.Game;

public class Main {

	public static void main(String[] args) {
		Game g = new Game();
		g.play();

	}

}
