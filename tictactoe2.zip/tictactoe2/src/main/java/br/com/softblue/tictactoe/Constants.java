package br.com.softblue.tictactoe;

public class Constants {

	public static final int BOARD_SIZE=3;
	
	public static final char[] SYMBOL_PLAYERS= {'X','O'};
	
		
}
